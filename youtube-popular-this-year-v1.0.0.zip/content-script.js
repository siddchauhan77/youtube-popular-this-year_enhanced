// YouTube Popular This Year Extension
// Content script that adds a "Popular This Year" filter to YouTube channel pages

class YouTubePopularThisYear {
  constructor() {
    this.isActive = false;
    this.originalVideos = [];
    this.filteredVideos = [];
    this.twelveMonthsAgo = new Date();
    this.twelveMonthsAgo.setMonth(this.twelveMonthsAgo.getMonth() - 12);
    this.observer = null;
    
    this.init();
  }

  init() {
    console.log('YouTube Popular This Year: Extension initialized');
    console.log('YouTube Popular This Year: Current URL:', window.location.href);
    
    // Wait for page to load and check if we're on a channel page
    if (this.isChannelPage()) {
      console.log('YouTube Popular This Year: Channel page detected');
      this.waitForSortButtons();
      this.setupMutationObserver();
    } else {
      console.log('YouTube Popular This Year: Not a channel page');
    }
  }

  isChannelPage() {
    // Check if we're on a YouTube channel page
    return window.location.pathname.includes('/channel/') || 
           window.location.pathname.includes('/c/') ||
           window.location.pathname.includes('/user/') ||
           window.location.pathname.includes('/@');
  }

  waitForSortButtons() {
    // Wait for the sort buttons to appear
    const observer = new MutationObserver((mutations) => {
      // Look specifically for video filter chips container
      const sortContainer = document.querySelector('ytd-feed-filter-chip-bar-renderer #chips, yt-chip-cloud-modern, yt-chip-cloud, #chips-container');
      if (sortContainer) {
        observer.disconnect();
        this.addPopularThisYearButton();
      }
    });

    observer.observe(document.body, {
      childList: true,
      subtree: true
    });

    // Also try to find it immediately in case it's already loaded
    const sortContainer = document.querySelector('ytd-feed-filter-chip-bar-renderer #chips, yt-chip-cloud-modern, yt-chip-cloud, #chips-container');
    if (sortContainer) {
      this.addPopularThisYearButton();
    }

    // Fallback: try to find after a short delay
    setTimeout(() => {
      const sortContainer = document.querySelector('ytd-feed-filter-chip-bar-renderer #chips, yt-chip-cloud-modern, yt-chip-cloud, #chips-container');
      if (sortContainer) {
        this.addPopularThisYearButton();
      }
    }, 2000);
  }

  setupMutationObserver() {
    // Watch for changes to the page that might remove our button
    this.observer = new MutationObserver((mutations) => {
      let shouldReaddButton = false;
      
      mutations.forEach((mutation) => {
        // Check if our button was removed
        if (mutation.type === 'childList') {
          mutation.removedNodes.forEach((node) => {
            if (node.nodeType === Node.ELEMENT_NODE) {
              if (node.classList && node.classList.contains('popular-this-year-btn')) {
                console.log('YouTube Popular This Year: Button was removed, will re-add');
                shouldReaddButton = true;
              }
              // Also check if the button is inside a removed node
              if (node.querySelector && node.querySelector('.popular-this-year-btn')) {
                console.log('YouTube Popular This Year: Button container was removed, will re-add');
                shouldReaddButton = true;
              }
            }
          });
        }
      });
      
      if (shouldReaddButton) {
        // Wait a bit for YouTube to finish updating
        setTimeout(() => {
          this.addPopularThisYearButton();
        }, 100);
      }
    });
    
    // Start observing the document body for changes
    this.observer.observe(document.body, {
      childList: true,
      subtree: true
    });
    
    console.log('YouTube Popular This Year: MutationObserver setup complete');
  }

  addPopularThisYearButton() {
    // Look for video filter chips container specifically
    const sortContainer = document.querySelector('ytd-feed-filter-chip-bar-renderer #chips, yt-chip-cloud-modern, yt-chip-cloud, #chips-container');
    if (!sortContainer) {
      console.log('YouTube Popular This Year: Video filter chips container not found');
      return;
    }

    // Check if button already exists
    if (sortContainer.querySelector('.popular-this-year-btn')) {
      console.log('YouTube Popular This Year: Button already exists in chips container');
      return;
    }

    console.log('YouTube Popular This Year: Adding button to chips container:', sortContainer);

    // Create the button
    const button = document.createElement('button');
    button.className = 'popular-this-year-btn';
    button.textContent = 'Popular This Year';
    button.addEventListener('click', () => this.handlePopularThisYearClick());

    // Insert the button at the end of the chips container (last position)
    sortContainer.appendChild(button);
    console.log('YouTube Popular This Year: Button added to chips container');
  }

  handlePopularThisYearClick() {
    console.log('YouTube Popular This Year: Button clicked');
    
    if (this.isActive) {
      this.resetToOriginal();
    } else {
      this.applyPopularThisYearFilter();
    }
    
    // Update button active state
    const button = document.querySelector('.popular-this-year-btn');
    if (button) {
      button.classList.toggle('active', this.isActive);
    }
  }

  applyPopularThisYearFilter() {
    // Store original videos
    this.originalVideos = this.extractVideoData();
    
    // Filter videos from past 12 months
    this.filteredVideos = this.originalVideos.filter(video => {
      return video.uploadDate >= this.twelveMonthsAgo;
    });

    // Sort by view count (descending)
    this.filteredVideos.sort((a, b) => b.viewCount - a.viewCount);

    // Update the display
    this.updateVideoDisplay();
    
    // Update button state
    const button = document.querySelector('.popular-this-year-btn');
    if (button) {
      button.classList.add('active');
      button.textContent = 'Show All Videos';
    }

    this.isActive = true;
  }

  resetToOriginal() {
    // Restore original video order
    this.updateVideoDisplay(this.originalVideos);
    
    // Update button state
    const button = document.querySelector('.popular-this-year-btn');
    if (button) {
      button.classList.remove('active');
      button.textContent = 'Popular This Year';
    }

    this.isActive = false;
  }

  cleanup() {
    if (this.observer) {
      this.observer.disconnect();
      this.observer = null;
      console.log('YouTube Popular This Year: MutationObserver disconnected');
    }
  }

  extractVideoData() {
    const videos = [];
    // Look for video elements in the main content area
    const videoElements = document.querySelectorAll('#contents ytd-rich-item-renderer, #contents ytd-video-renderer, ytd-rich-item-renderer, ytd-video-renderer');
    
    console.log('YouTube Popular This Year: Found', videoElements.length, 'video elements');
    
    videoElements.forEach((element, index) => {
      const videoData = this.parseVideoElement(element, index);
      if (videoData) {
        videos.push(videoData);
        console.log('YouTube Popular This Year: Parsed video:', videoData.title, 'Views:', videoData.viewCount, 'Date:', videoData.uploadDate);
      }
    });

    return videos;
  }

  parseVideoElement(element, index) {
    try {
      // Extract video title and link - try multiple selectors
      const titleElement = element.querySelector('#video-title, a#video-title, h3 a, ytd-video-meta-block a');
      if (!titleElement) {
        console.log('YouTube Popular This Year: No title element found for video', index);
        return null;
      }

      const title = titleElement.textContent.trim();
      const videoUrl = titleElement.href;

      // Extract view count and date from all text content
      const allText = element.textContent;
      console.log('YouTube Popular This Year: All text content:', allText);
      
      // Try to find view count in the text
      const viewCountMatch = allText.match(/(\d+(?:\.\d+)?[kmb]?)\s*views?/i);
      let viewCount = 0;
      if (viewCountMatch) {
        viewCount = this.parseViewCount(viewCountMatch[1] + ' views');
      }

      // Try to find date in the text
      const dateMatch = allText.match(/(\d+\s*(?:hour|day|week|month|year)s?\s*ago)/i);
      let uploadDate = null;
      if (dateMatch) {
        uploadDate = this.parseUploadDate(dateMatch[1]);
      }

      console.log('YouTube Popular This Year: Parsed video element:', {
        title: title.substring(0, 50) + '...',
        viewCount: viewCount,
        uploadDate: uploadDate,
        hasElement: !!element
      });

      return {
        element: element,
        title: title,
        url: videoUrl,
        viewCount: viewCount,
        uploadDate: uploadDate,
        originalIndex: index
      };
    } catch (error) {
      console.error('YouTube Popular This Year: Error parsing video element:', error);
      return null;
    }
  }

  parseViewCount(viewCountText) {
    if (!viewCountText) return 0;
    
    console.log('YouTube Popular This Year: Parsing view count:', viewCountText);
    
    // Remove common words and clean the text
    let text = viewCountText.toLowerCase()
      .replace(/views?/g, '')
      .replace(/view/g, '')
      .replace(/,/g, '')
      .trim();
    
    console.log('YouTube Popular This Year: Cleaned view count text:', text);
    
    if (text.includes('k')) {
      const num = parseFloat(text.replace('k', ''));
      return Math.floor(num * 1000);
    } else if (text.includes('m')) {
      const num = parseFloat(text.replace('m', ''));
      return Math.floor(num * 1000000);
    } else if (text.includes('b')) {
      const num = parseFloat(text.replace('b', ''));
      return Math.floor(num * 1000000000);
    } else {
      const num = parseFloat(text);
      return isNaN(num) ? 0 : Math.floor(num);
    }
  }

  parseUploadDate(dateText) {
    if (!dateText) return null;
    
    console.log('YouTube Popular This Year: Parsing upload date:', dateText);
    
    const text = dateText.toLowerCase();
    const now = new Date();
    
    if (text.includes('hour')) {
      const hours = parseInt(text.match(/\d+/)?.[0] || '0');
      const date = new Date(now.getTime() - hours * 60 * 60 * 1000);
      console.log('YouTube Popular This Year: Parsed as', hours, 'hours ago:', date);
      return date;
    } else if (text.includes('day')) {
      const days = parseInt(text.match(/\d+/)?.[0] || '0');
      const date = new Date(now.getTime() - days * 24 * 60 * 60 * 1000);
      console.log('YouTube Popular This Year: Parsed as', days, 'days ago:', date);
      return date;
    } else if (text.includes('week')) {
      const weeks = parseInt(text.match(/\d+/)?.[0] || '0');
      const date = new Date(now.getTime() - weeks * 7 * 24 * 60 * 60 * 1000);
      console.log('YouTube Popular This Year: Parsed as', weeks, 'weeks ago:', date);
      return date;
    } else if (text.includes('month')) {
      const months = parseInt(text.match(/\d+/)?.[0] || '0');
      const date = new Date(now.getTime() - months * 30 * 24 * 60 * 60 * 1000);
      console.log('YouTube Popular This Year: Parsed as', months, 'months ago:', date);
      return date;
    } else if (text.includes('year')) {
      const years = parseInt(text.match(/\d+/)?.[0] || '0');
      const date = new Date(now.getTime() - years * 365 * 24 * 60 * 60 * 1000);
      console.log('YouTube Popular This Year: Parsed as', years, 'years ago:', date);
      return date;
    }
    
    console.log('YouTube Popular This Year: Could not parse date:', dateText);
    return null;
  }

  updateVideoDisplay(videos = this.filteredVideos) {
    const container = document.querySelector('#contents');
    if (!container) return;

    // Clear current videos
    container.innerHTML = '';

    // Add filtered videos
    videos.forEach(video => {
      container.appendChild(video.element);
    });
  }
}

// Initialize the extension when the page loads
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', () => {
    new YouTubePopularThisYear();
  });
} else {
  new YouTubePopularThisYear();
}

// Re-initialize on navigation (for SPA behavior)
let currentUrl = window.location.href;
const urlObserver = new MutationObserver(() => {
  if (window.location.href !== currentUrl) {
    currentUrl = window.location.href;
    // Small delay to let the page load
    setTimeout(() => {
      if (document.querySelector('.popular-this-year-btn')) {
        document.querySelector('.popular-this-year-btn').remove();
      }
      new YouTubePopularThisYear();
    }, 1000);
  }
});

urlObserver.observe(document.body, {
  childList: true,
  subtree: true
});
